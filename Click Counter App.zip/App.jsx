import React from "react";
import ClickCounter from "./ClickCounter";

export default function App() {
  return <ClickCounter />;
}